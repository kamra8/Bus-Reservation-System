

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class customersearchbus extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter pw=response.getWriter();
	
		pw.println("<html><head><title>Bootstrap Example</title><script src='../jquery.min.js'></script><script src='../bootstrap.min.js'></script>");
		pw.println("<link rel='stylesheet' href='../bootstrap.min.css'><link rel='stylesheet' type='text/css' href='../customersearchbus.css'>");
		pw.println("<link rel='stylesheet' type='text/css' href='../manager.css'><link rel='stylesheet' type='text/css' href='../navigationbar.css'></head>");
		pw.println("<body><div id='main'><div id='div1'><ul id='ul1'><li id='dreamtravel'><font style='color: #ffffff'>DREAM TRAVEL</font></li><li id='home'><a href='../customersearchbus.html'>Home</a></li>");
		pw.println("<li style='float:right' id='log out'><a class='active' href='../login1.html'>Log Out</a></li></ul></div><div id='div2'><div id='div21'>");
		pw.println("<h2 id='h2'>Book Ticket</h2></div>");
		pw.println("<div id='div22'>");
		
		pw.println(" <div class='container'> <div class='row'> <div class='panel panel-default'>");
		pw.println("<div class='panel-heading'></div><table class='table table-fixed'>");
		pw.println("<thead> <tr><th class='col-xs-2'>Operator</th><th class='col-xs-8'>BusType</th><th class='col-xs-2'>Departure</th><th class='col-xs-2'>Arrival</th><th class='col-xs-2'>Available Seat</th><th class='col-xs-2'>Price</th></tr></thead>");
		String s1=request.getParameter("src");
		String s2=request.getParameter("dest");
		String s3=request.getParameter("date1");
		
		
		DateFormat df= new SimpleDateFormat("yyyy-mm-dd");
		Date date = new Date();
		String testDateString = df.format(date);
		
		   
		try
		{
			if(df.parse(s3).after(df.parse(testDateString)))
			{
		HttpSession session=request.getSession();
		session.setAttribute("src",s1);
		session.setAttribute("dest", s2);
		session.setAttribute("date", s3);
		Connection con=DbInfo1.con;
		String str="select operator,type,dtime,atime,numseat,fare,id from bus where srcstn=? AND deststn=?";
		try {
			PreparedStatement ps=con.prepareStatement(str);
			ps.setString(1, s1);
			ps.setString(2, s2);
			System.out.println(s1);
			System.out.println(s2);
			ResultSet rs=ps.executeQuery();
			pw.println("<div class='scrollit'><tbody>");
			while(rs.next())
			{
				String avaiseat;
				String operator=rs.getString("operator");
				String bustype=rs.getString("type");
				String dtime=rs.getString("dtime");
				String atime=rs.getString("atime");
				String numseat=rs.getString("numseat");
				String fare=rs.getString("fare");
				String id=rs.getString("id");
				String str11="select seatavai from seatavailable where busid=? 	AND date=?";
				PreparedStatement psa=con.prepareStatement(str11);
				  psa.setString(1, id);
				  psa.setString(2, s3);
				 ResultSet res1= psa.executeQuery();
				 if(res1.next())
				  avaiseat=res1.getString("seatavai");
				 else
					 avaiseat=numseat;
				pw.println("<tr><td class='col-xs-2'>"+operator+"</td><td class='col-xs-8'>"+bustype+"</td><td class='col-xs-2'>"+dtime+"</td><td class='col-xs-2'>"+atime+"</td><td class='col-xs-2'>"+avaiseat+"</td><td class='col-xs-2'>"+fare+"</td>");
				pw.println("<td class='col-xs-2'><form action='numberofpassenger'>Proceed<input type='submit' value="+id+" name='iddemo'></form></td></tr>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		            
		pw.println("</div></tbody></table>");
		pw.println("</div></div></div></div>");
		pw.println("<div id='div3'><div id='div31'><h3 id='h321'>customer services</h3><a href='print.html' id='link311'>Print Ticket</a><br><br><a href='cancelticket.html' id='link312'>Cancel Ticket</a></div><div id='div32'><h3 id='h321'>Why DreamTravel?</h3>");
		pw.println("<h4 id='h322'>A service that has standardized and centralized India's bus system.24x7 Dedicated helpline and over 5 million delighted customers & still growing.Without any standardization of pricing or centralization of routes, fares and information about the bus fleets, India's bus system ran like the rest of the country tends to - in complete chaos.<h4>");
		pw.println("</div><div id='div4'>");
		pw.println("<div id='div41'><table id='table41'><tr><th>Top Cities</th></tr><tr><td ><p>Jaipur</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Bangalore</p></td></tr><br><tr><td><p>Pune</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td> ");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai</p></td></tr><tr><td ><p>Hyderabad</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Delhi</p></td></tr><tr><td ><p>Coimbatore</p></td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Ahemdabad</p></td></tr><tr><td ><p>Chennai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Varanasi</p></td></tr></table></div><div id='div42'><table id='table42'>");
		pw.println("<tr><th>Top Bus Operators</th></tr><tr><td><p>SRS Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>VRL Travels</p></td></tr><br><tr><td ><p>KPN Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>  ");
		pw.println("&nbsp;</td><td>&nbsp;</td><td><p>Kallada Travels</p></td></tr><tr><td ><p>SRM Transports</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Orange Tours & Travels</p></td></tr><tr><td ><p>Sea bird Tourist</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>");
		pw.println("&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Paulo Travels</p></td></tr><tr><td ><p>kesineni Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Eagle Falcon Bus</p></td></tr></table></div><div id='div43'><table id='table43'><tr><th>");
		pw.println("Top Bus Routes</th></tr><tr><td ><p>Hyderabad to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Bangalore to Chennai</p></td></tr><br><tr><td ><p>Pune to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai to Bangalore</p></td></tr><tr><td ><p>Hyderabad to Chennai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Pune to Hyderabad</p></td></tr><tr><td ><p>Coimbatore to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai to Hyderabad</p></td></tr><tr><td ><p>Chennai to Madurai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td><p>Jaipur to Delhi</p></td></tr></table></div></div><div id='div5'><table id='table51'><tr><td><a href='../aboutus.html'>About DreamTravel.</a>");
		pw.println("</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><a href='../faq.html'>FAQ.</a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='../privacypolicy.html'>Private Policy</a></td></tr></table></div><div id='div6'><table id='table61'><tr><td>");
		pw.println("<a href='https://www.goibibo.com/'><img src='../Goibibo.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='https://www.tripadvisor.in/'><img src='../tripavisor.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td ><img src='../rat.jpg' ></td></tr></table></div></div></body></html>");
		}
			else
			{
				response.sendRedirect("../customersearchbusnotfound.html");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	
	}        
	    
}

