

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class viewregistereduser extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter pw=response.getWriter();
	
		pw.println("<html><head><title>Bootstrap Example</title><script src='../jquery.min.js'></script><script src='../bootstrap.min.js'></script>");
		pw.println("<link rel='stylesheet' href='../bootstrap.min.css'><link rel='stylesheet' type='text/css' href='../viewregistereduser.css'>");
		pw.println("<link rel='stylesheet' type='text/css' href='../manager.css'><link rel='stylesheet' type='text/css' href='../navigationbar.css'></head>");
		pw.println("<body><div id='main'><div id='div1'><ul id='ul1'><li id='dreamtravel'><font style='color: #ffffff'>DREAM TRAVEL</font></li><li id='home'><a href='#home'>Home</a></li>");
		pw.println("<li style='float:right' id='log out'><a class='active' href='../login1.html'>Log Out</a></li></ul></div><div id='div2'><div id='div21'><ul><li><a  href='../manager.html'>Add New Bus</a></li>");
		pw.println("<li><a class='active' href='#'>View Registered User</a></li><li><a href='../searchbus.html'>Search bus</a></li><li><a href='../delete.html'>Delete Bus</a></li><li><a  href='../updatebusdetail.html'>Update Bus Details</a></li></ul></div>");
		pw.println("<div id='div22'>");
		
		Connection con=DbInfo1.con;
		String str="select username,password from reg where utype='customer'";
		try {
			PreparedStatement ps=con.prepareStatement(str);
			java.sql.ResultSet res=ps.executeQuery();
			pw.println("<table class='table table-striped'");
			pw.println("<caption><h1>Registered User</h1></caption>");
			pw.println("<thead><tr><th>USERNAME</th>");
			pw.println("<th>PASSWORD</th></tr></thead><tbody>");
			while(res.next())
			{
				pw.println("<tr><td>"+ res.getString(1) +"</td>");
				pw.println("<td>"+res.getString(2)+"</td></tr>");
			}
			
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
	pw.println("</tbody></table>");
		pw.println("</div></div>");
		pw.println("<div id='div6'><table id='table61'><tr><td>");
		pw.println("<a href='https://www.goibibo.com/'><img src='../Goibibo.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='https://www.tripadvisor.in/'><img src='../tripavisor.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td ><img src='../rat.jpg' ></td></tr></table></div></div></body></html>");

	}        
	    
	}

