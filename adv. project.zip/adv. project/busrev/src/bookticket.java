

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class bookticket extends HttpServlet {
	
	int num=0;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter pw=response.getWriter();
	
		pw.println("<html><head><title>Bootstrap Example</title><script src='../jquery.min.js'></script><script src='../bootstrap.min.js'></script>");
		pw.println("<link rel='stylesheet' href='../bootstrap.min.css'><link rel='stylesheet' type='text/css' href='../bookticket.css'>");
		pw.println("<link rel='stylesheet' type='text/css' href='../manager.css'><link rel='stylesheet' type='text/css' href='../navigationbar.css'></head>");
		pw.println("<body><div id='main'><div id='div1'><ul id='ul1'><li id='dreamtravel'><font style='color: #ffffff'>DREAM TRAVEL</font></li><li id='home'><a href='#home'>Home</a></li>");
		pw.println("<li style='float:right' id='log out'><a class='active' href='../login1.html'>Log Out</a></li></ul></div><div id='div2'><div id='div21'>");
		pw.println("<h2 id='h2'>Book Ticket</h2></div>");
		pw.println("<div id='div22'>");
		Connection con=DbInfo1.con;
		String s1=request.getParameter("numtkt");
		int s2=Integer.parseInt(s1);
		num=s2;
		pw.println("<form id='booktkt' action='bookticket' method='post'>");
		pw.println("<h3>Please Fill All Details</h3>");
		for(int i=0;i<s2;i++)
		{
			pw.println("Passenger Name&nbsp&nbsp&nbsp&nbsp<input type='text'  name=uname" + i + " >");
			pw.println("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp");
			pw.println("<input type='radio' value='M'  name=gender"+i+">M");
			pw.println("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp");
			pw.println("<input type='radio' value='F' name=gender"+i+">F");
			pw.println("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp");
			pw.println("Age&nbsp&nbsp&nbsp&nbsp<input type='text' name=age"+i+">");
			pw.println("<br>");pw.println("<br>");
		}
		pw.println("<br>Enter Email-Id&nbsp&nbsp&nbsp&nbsp<input type='text' name='email' >");pw.println("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp");pw.println("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp");pw.println("&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp");
		pw.println("Mobile-no&nbsp&nbsp&nbsp&nbsp<input type='text' name='mobno' > ");pw.println("<br>");pw.println("<br>");
		pw.println("Ticket Number&nbsp&nbsp&nbsp&nbsp<input type='text'  name='tktno' id='tktno' readonly='readonly'>");pw.println("<br>");pw.println("<br>");
		pw.println("<script>");
		{
			pw.println("var x=document.getElementById('tktno');");
			pw.println("x.value=Math.floor((Math.random()*1000000)+1);");
		}
		pw.println("</script>");
		
		pw.println("<br><input type='submit' value='Book Ticket' >");
		pw.println("<script>");
		   {
			   pw.println("var xmlHttp = new XMLHttpRequest()");
			   pw.println("var value11 = document.getElementById('tktno').value");
			   pw.println("var value22 = document.getElementById('mobno').value;");
			   pw.println("var value33 = document.getElementById('email').value;");
			   for(int k=0;k<num;k++)
			   {
				   pw.println("var value"+k+" = document.getElementById(uname"+k+").value");
				   pw.println("var val"+k+" = document.getElementById(gender"+k+").value");
				   pw.println("var valu"+k+" = document.getElementById(age"+k+").value");
				   
			   }
			   pw.println("xmlHttp.open('POST', 'bookticket', false)");
			   pw.println("xmlHttp.send(value11)");
			   pw.println("xmlHttp.send(value22)");
			   pw.println("xmlHttp.send(value33)");
			   for(int x=0;x<num;x++)
			   {
				   pw.println("xmlHttp.send(value"+x+")");
				   pw.println("xmlHttp.send(val"+x+")");
				   pw.println("xmlHttp.send(valu"+x+")");
			   }
		  }
		   pw.println("</script>");
		
		
		
		pw.println("</form></div>");
		
		pw.println("<div id='div3'><div id='div31'><h3 id='h321'>customer services</h3><a href='print.html' id='link311'>Print Ticket</a><br><br><a href='cancelticket.html' id='link312'>Cancel Ticket</a></div><div id='div32'><h3 id='h321'>Why DreamTravel?</h3>");
		pw.println("<h4 id='h322'>A service that has standardized and centralized India's bus system.24x7 Dedicated helpline and over 5 million delighted customers & still growing.Without any standardization of pricing or centralization of routes, fares and information about the bus fleets, India's bus system ran like the rest of the country tends to - in complete chaos.<h4>");
		pw.println("</div><div id='div4'>");
		pw.println("<div id='div41'><table id='table41'><tr><th>Top Cities</th></tr><tr><td ><p>Jaipur</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Bangalore</p></td></tr><br><tr><td><p>Pune</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td> ");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai</p></td></tr><tr><td ><p>Hyderabad</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Delhi</p></td></tr><tr><td ><p>Coimbatore</p></td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Ahemdabad</p></td></tr><tr><td ><p>Chennai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Varanasi</p></td></tr></table></div><div id='div42'><table id='table42'>");
		pw.println("<tr><th>Top Bus Operators</th></tr><tr><td><p>SRS Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>VRL Travels</p></td></tr><br><tr><td ><p>KPN Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>  ");
		pw.println("&nbsp;</td><td>&nbsp;</td><td><p>Kallada Travels</p></td></tr><tr><td ><p>SRM Transports</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Orange Tours & Travels</p></td></tr><tr><td ><p>Sea bird Tourist</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>");
		pw.println("&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Paulo Travels</p></td></tr><tr><td ><p>kesineni Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Eagle Falcon Bus</p></td></tr></table></div><div id='div43'><table id='table43'><tr><th>");
		pw.println("Top Bus Routes</th></tr><tr><td ><p>Hyderabad to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Bangalore to Chennai</p></td></tr><br><tr><td ><p>Pune to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai to Bangalore</p></td></tr><tr><td ><p>Hyderabad to Chennai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Pune to Hyderabad</p></td></tr><tr><td ><p>Coimbatore to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai to Hyderabad</p></td></tr><tr><td ><p>Chennai to Madurai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td><p>Jaipur to Delhi</p></td></tr></table></div></div><div id='div5'><table id='table51'><tr><td><a href='../aboutus.html'>About DreamTravel.</a>");
		pw.println("</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><a href='../faq.html'>FAQ.</a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='../privacypolicy.html'>Private Policy</a></td></tr></table></div><div id='div6'><table id='table61'><tr><td>");
		pw.println("<a href='https://www.goibibo.com/'><img src='../Goibibo.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='https://www.tripadvisor.in/'><img src='../tripavisor.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td ><img src='../rat.jpg' ></td></tr></table></div></div></body></html>");

	}        
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String seatavai="";
			Connection con=DbInfo1.con;
			String str2="select numseat from bus where id=?";
			HttpSession session=request.getSession();
			session.getAttribute("busid");
			session.getAttribute("src");
			session.getAttribute("dest");
			session.getAttribute("date");
			String busid=(String)session.getAttribute("busid");
			String src=(String)session.getAttribute("src");
			String dest=(String)session.getAttribute("dest");
			String date=(String)session.getAttribute("date");
			System.out.println(src+"check");
			System.out.println(dest+"check");
			System.out.println(date+"check");
			String email=request.getParameter("email");
			String tktno=request.getParameter("tktno");
			String mobno=request.getParameter("mobno");
			PreparedStatement ps3;
			try {
				ps3 = con.prepareStatement(str2);
				ps3.setString(1, busid);
				ResultSet res=ps3.executeQuery();
				res.next();
				 seatavai=res.getString("numseat");
			} catch (SQLException e2) {
				// TODO Auto-generated catch block
				e2.printStackTrace();
			}
			
			String str="select * from seatavailable where busid=? AND date=?"; 
			try {
				PreparedStatement ps1=con.prepareStatement(str);
				ps1.setString(1,busid);
				ps1.setString(2,date);
				ResultSet rs=ps1.executeQuery();
				
				if(rs.next() )
				{
					
				}
				else
				{
					String str1="insert into seatavailable values(?,?,?)";
					PreparedStatement ps2=con.prepareStatement(str1);
					ps2.setString(1,busid);
					ps2.setString(2,date);
					ps2.setString(3, seatavai);
					ps2.executeUpdate();
					System.out.println(seatavai);
				}
			
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
			HttpSession sess=request.getSession();
			sess.setAttribute("tktno",tktno);
			
			for(int j=0;j<num;j++)
			{
				String name=request.getParameter("uname"+j);
				String gender=request.getParameter("gender"+j);
				String age=request.getParameter("age"+j);
				String query="insert into tkt values(?,?,?,?,?,?,?,?,?,?)";
				PreparedStatement ps;
				try {
					ps = con.prepareStatement(query);
					ps.setString(1, busid);
					ps.setString(2,src);
					ps.setString(3,dest);
					ps.setString(4,date);
					ps.setString(5,tktno);
					ps.setString(6,name);
					ps.setString(7,gender);
					ps.setString(8,age);
					ps.setString(9, email);
					ps.setString(10, mobno);
					int i=ps.executeUpdate();
					String num1=String.valueOf(num);
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
			}
			String num1=String.valueOf(num);
			System.out.println(num1);
			String str3="update seatavailable set seatavai=seatavai-"+num1+" where busid=? AND date=?";
			PreparedStatement ps4;
			try {
				ps4 = con.prepareStatement(str3);
				ps4.setString(1,busid);
				ps4.setString(2,date);
				ps4.executeUpdate();
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			response.sendRedirect("ticket");
	}   
}

