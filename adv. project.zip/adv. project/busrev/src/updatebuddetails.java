

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class updatebuddetails extends HttpServlet {
	
	String  id;
    	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		id=request.getParameter("idd");
		System.out.println(id);
		Connection con=DbInfo1.con;
		String query="select no,type,operator,srcstn,deststn,fare,dtime,atime,stadd,contact,numseat from bus where id="+id;
		System.out.println(query);
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ResultSet res=ps.executeQuery();
			res.next();
			String no=res.getString("no");
			String type=res.getString("type");
			String operator=res.getString("operator");
			String srcstn=res.getString("srcstn");
			String deststn=res.getString("deststn");
			String fare=res.getString("fare");
			String dtime=res.getString("dtime");
			String atime=res.getString("atime");
			String stadd=res.getString("stadd");
			String contact=res.getString("contact");
			String numseat=res.getString("numseat");
		
		
		PrintWriter pw=response.getWriter();
		pw.println("<html><head><title>Bootstrap Example</title><script src='../jquery.min.js'></script><script src='../bootstrap.min.js'></script>");
				pw.println("<link rel='stylesheet' href='../bootstrap.min.css'><link rel='stylesheet' type='text/css' href='../manager1.css'><link rel='stylesheet' type='text/css' href='../manager.css'>");
		pw.println("<link rel='stylesheet' type='text/css' href='../navigationbar.css'>");
		pw.println("</head><body><div id='main'><div id='div1'><ul id='ul1'><li id='dreamtravel'><font style='color: #ffffff'>DREAM TRAVEL</font></li><li id='home'><a href='#home'>Home</a></li><li style='float:right' id='log out'><a class='active' href='login1.html'>Log Out</a></li></ul></div><div id='div2'><div id='div21'><ul>");
		pw.println("<li><a  href='manager.html'>Add New Bus</a></li><li><a href='servlet/viewregistereduser'>View Registered User</a></li><li><a href='searchbus.html'>Search bus</a></li><li><a href='delete.html'>Delete Bus</a></li><li><a class='active' href='#'>Update Bus Details</a></li></ul></div><div id='div22'>");
		pw.println("<form id='addbus' action='updatebuddetails' method='post'>");
		pw.println("<font style='color:#000000 '>Bus Id</font><input type='text'  required='required' id='addbustb1' name='idd' value="+id+" ><br><br>");
		pw.println("<font style='color:#000000 '>Bus No.</font><input type='text' required='required' id='addbustb2' name='no' value="+no+"><br><br>");
		pw.println("<font style='color:#000000 '>Bus Type</font><input type='text' id='addbustb3' required='required' name='type' value="+type+"><br><br>");
		pw.println("<font style='color:#000000 '>Bus Operator</font><input type='text' required='required' id='addbustb4' name='operator' value="+operator+"><br><br>");
		pw.println("<font style='color:#000000 '>Source Station</font><input type='text' id='addbustb5' required='required' name='srcstn' value="+srcstn+"><br><br>");
		pw.println("<font style='color:#000000 '>Destination Station</font><input type='text' id='addbustb6' required='required' name='deststn' value="+deststn+"><br><br>");
		pw.println("<font style='color:#000000 '>Fare</font><input type='text' id='addbustb7' required='required' name='fare' value="+fare+"><br><br>");
		pw.println("<font style='color:#000000 '>Departure Time</font><input type='time' id='addbustb8' required='required' name='dtime' value="+dtime+"><br><br>");
		pw.println("<font style='color:#000000 '>Arrival Time</font><input type='time' id='addbustb10' required='required' name='atime' value="+atime+"><br><br>");
		pw.println("<font style='color:#000000 '>Starting Address</font><input type='text' id='addbustb9' required='required' name='stadd' value="+stadd+"><br><br>");
		pw.println("<font style='color:#000000 '>Contact No.</font><input type='text' id='addbustb11' required='required' name='contact' value="+contact+"><br><br>");
		pw.println("<font style='color:#000000 '>Number Of Seats</font><input type='text' id='addbustb12' required='required' name='numseat' value="+numseat+"><br><br>");
		pw.println("<br><br><input type='submit' value='Update' id='addbusbutton'></form></div></div><div id='div6'><table id='table61'><tr><td >");
		pw.println("<a href='https://www.goibibo.com/'><img src='../Goibibo.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='https://www.tripadvisor.in/'><img src='../tripavisor.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td ><img src='../rat.jpg' ></td></tr></table></div></div></body></html>");
		
		
		pw.println("<script>");
		   {
			   pw.println("var xmlHttp = new XMLHttpRequest()");
			   pw.println("var value1 = document.getElementById('numseat').value");
			   pw.println("var value2 = document.getElementById('no').value;");
			   pw.println("var value3 = document.getElementById('type').value");
			   pw.println("var value4 = document.getElementById('operator').value;");
			   pw.println("var value5 = document.getElementById('srcstn').value");
			   pw.println("var value6 = document.getElementById('deststn').value;");
			   pw.println("var value7 = document.getElementById('fare').value");
			   pw.println("var value8 = document.getElementById('dtime').value;");
			   pw.println("var value9 = document.getElementById('atime').value");
			   pw.println("var value10 = document.getElementById('stadd').value;");
			   pw.println("var value11= document.getElementById('contact').value;");
			   pw.println("xmlHttp.open('POST', 'updatebuddetails', false)");
			   pw.println("xmlHttp.send(value1)");
			   pw.println("xmlHttp.send(value2)");
			   pw.println("xmlHttp.send(value3)");
			   pw.println("xmlHttp.send(value4)");
			   pw.println("xmlHttp.send(value5)");
			   pw.println("xmlHttp.send(value6)");
			   pw.println("xmlHttp.send(value7)");
			   pw.println("xmlHttp.send(value8)");
			   pw.println("xmlHttp.send(value9)");
			   pw.println("xmlHttp.send(value10)");
			   pw.println("xmlHttp.send(value11)");
		  }
		   pw.println("</script>");
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String no=request.getParameter("no");
		String type=request.getParameter("type");
		String operator=request.getParameter("operator");
		String srcstn=request.getParameter("srcstn");
		String deststn=request.getParameter("deststn");
		String fare=request.getParameter("fare");
		String dtime=request.getParameter("dtime");
		String atime=request.getParameter("atime");
		String stadd=request.getParameter("stadd");
		String contact=request.getParameter("contact");
		String numseat=request.getParameter("numseat");
		String query="update bus SET no=?,type=?,operator=?,srcstn=?,deststn=?,fare=?,dtime=?,atime=?,stadd=?,contact=?,numseat=? where id="+id;
		Connection con=DbInfo1.con;
		System.out.println(query);
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, no);
			ps.setString(2, type);
			ps.setString(3, operator);
			ps.setString(4, srcstn);
			ps.setString(5, deststn);
			ps.setString(6, fare);
			ps.setString(7, dtime);
			ps.setString(8, atime);
			ps.setString(9, stadd);
			ps.setString(10, contact);
			ps.setString(11, numseat);
			int i=ps.executeUpdate();
			System.out.println(i);
			response.sendRedirect("../updatebusdetail.html");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
	}

}
