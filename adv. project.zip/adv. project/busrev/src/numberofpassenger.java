

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class numberofpassenger
 */
@WebServlet("/numberofpassenger")
public class numberofpassenger extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public numberofpassenger() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		String busid=request.getParameter("iddemo");
		System.out.println(busid);
		HttpSession session=request.getSession();
		session.setAttribute("busid",busid);
		pw.println("<html><head><title>Bootstrap Example</title><script src='../jquery.min.js'></script><script src='../bootstrap.min.js'></script>");
		pw.println("<link rel='stylesheet' href='../bootstrap.min.css'><link rel='stylesheet' type='text/css' href='../numberofpassenger.css'>");
		pw.println("<link rel='stylesheet' type='text/css' href='../manager.css'><link rel='stylesheet' type='text/css' href='../navigationbar.css'></head>");
		pw.println("<body><div id='main'><div id='div1'><ul id='ul1'><li id='dreamtravel'><font style='color: #ffffff'>DREAM TRAVEL</font></li><li id='home'><a href='#home'>Home</a></li>");
		pw.println("<li style='float:right' id='log out'><a class='active' href='login1.html'>Log Out</a></li></ul></div>");
	
		
		
		
		pw.println("<div id='div2'><div id='div21'><h2 id='h2'>Select Number Of Seats</h2></div><div id='div22'><form id='form1' action='bookticket'><select id='dropdown1' name='numtkt'>");
		pw.println("<option>1</option><option>2</option><option>3</option><option>4</option><option>5</option><option>6</option></select><br><br><br><br><input  type='submit'  id='button1' value='Proceed'></form></div></div>");
		pw.println("<div id='div3'><div id='div31'><h3 id='h321'>customer services</h3><a href='../print.html' id='link311'>Print Ticket</a><br><br><a href='../cancelticket.html' id='link312'>Cancel Ticket</a></div><div id='div32'><h3 id='h321'>Why DreamTravel?</h3>");
		pw.println("<h4 id='h322'>A service that has standardized and centralized India's bus system.24x7 Dedicated helpline and over 5 million delighted customers & still growing.Without any standardization of pricing or centralization of routes, fares and information about the bus fleets, India's bus system ran like the rest of the country tends to - in complete chaos.<h4>");
		pw.println("</div><div id='div4'>");
		pw.println("<div id='div41'><table id='table41'><tr><th>Top Cities</th></tr><tr><td ><p>Jaipur</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Bangalore</p></td></tr><br><tr><td><p>Pune</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td> ");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai</p></td></tr><tr><td ><p>Hyderabad</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Delhi</p></td></tr><tr><td ><p>Coimbatore</p></td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Ahemdabad</p></td></tr><tr><td ><p>Chennai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Varanasi</p></td></tr></table></div><div id='div42'><table id='table42'>");
		pw.println("<tr><th>Top Bus Operators</th></tr><tr><td><p>SRS Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>VRL Travels</p></td></tr><br><tr><td ><p>KPN Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>  ");
		pw.println("&nbsp;</td><td>&nbsp;</td><td><p>Kallada Travels</p></td></tr><tr><td ><p>SRM Transports</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Orange Tours & Travels</p></td></tr><tr><td ><p>Sea bird Tourist</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>");
		pw.println("&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Paulo Travels</p></td></tr><tr><td ><p>kesineni Travels</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Eagle Falcon Bus</p></td></tr></table></div><div id='div43'><table id='table43'><tr><th>");
		pw.println("Top Bus Routes</th></tr><tr><td ><p>Hyderabad to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Bangalore to Chennai</p></td></tr><br><tr><td ><p>Pune to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai to Bangalore</p></td></tr><tr><td ><p>Hyderabad to Chennai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Pune to Hyderabad</p></td></tr><tr><td ><p>Coimbatore to Bangalore</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><p>Mumbai to Hyderabad</p></td></tr><tr><td ><p>Chennai to Madurai</p></td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td>");
		pw.println("<td><p>Jaipur to Delhi</p></td></tr></table></div></div><div id='div5'><table id='table51'><tr><td><a href='../aboutus.html'>About DreamTravel.</a>");
		pw.println("</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td><a href='../faq.html'>FAQ.</a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='../privacypolicy.html'>Private Policy</a></td></tr></table></div><div id='div6'><table id='table61'><tr><td>");
		pw.println("<a href='https://www.goibibo.com/'><img src='../Goibibo.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='https://www.tripadvisor.in/'><img src='../tripavisor.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td ><img src='../rat.jpg' ></td></tr></table></div></div></body></html>");

	}        
	    

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
