

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ticket
 */
@WebServlet("/ticket")
public class ticket extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ticket() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		Connection con=DbInfo1.con;
		HttpSession sess=request.getSession();
		String tktnumber=(String)sess.getAttribute("tktno");
		String query="select * from tkt where tktnum=?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, tktnumber);
			ResultSet res=ps.executeQuery();
			res.next();
			String src=res.getString("src");
			String dest=res.getString("dest");
			String date=res.getString("date");
			String tktnum=res.getString("tktnum");
			String busid=res.getString("busid");
			String query2="select * from bus where id=?";
			PreparedStatement ps1=con.prepareStatement(query2);
			ps1.setString(1, busid);
			ResultSet res1=ps1.executeQuery();
			res1.next();
			String operator=res1.getString("operator");
			String type=res1.getString("type");
			String dtime=res1.getString("dtime");
			String stadd=res1.getString("stadd");
			String fare=res1.getString("fare");
			int fare1=Integer.parseInt(fare);
			int k=0;
			res.previous();
			pw.println("<table align='center'><tr><th>"+src+" to "+dest+"</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>"+date+"</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>"+operator+"</th><tr></table>");
			pw.println("<br>");pw.println("<br>");
			pw.println("<table align='center'><tr><th>passenger name</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>age</th></tr>");
			while(res.next())
			{
				k=fare1+k;
				pw.println("<tr><td>"+res.getString("name")+"</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>"+res.getString("age")+"</td></tr>");
			}
			pw.println("</table><br>");pw.println("<br>");
			pw.println("<table align='center'><tr><th>Total Fare</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>Boarding Address</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>Departure Time</th></tr><tr><td>"+k+"</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>"+stadd+"</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>"+dtime+"</td><td></td></tr></table>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw=response.getWriter();
		Connection con=DbInfo1.con;
		String tktnumber=request.getParameter("tktno");
		String query="select * from tkt where tktnum=?";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			ps.setString(1, tktnumber);
			ResultSet res=ps.executeQuery();
			res.next();
			String src=res.getString("src");
			String dest=res.getString("dest");
			String date=res.getString("date");
			String tktnum=res.getString("tktnum");
			String busid=res.getString("busid");
			String query2="select * from bus where id=?";
			PreparedStatement ps1=con.prepareStatement(query2);
			ps1.setString(1, busid);
			ResultSet res1=ps1.executeQuery();
			res1.next();
			String operator=res1.getString("operator");
			String type=res1.getString("type");
			String dtime=res1.getString("dtime");
			String stadd=res1.getString("stadd");
			String fare=res1.getString("fare");
			int fare1=0;
			try
			{
			 fare1=Integer.parseInt(fare);
			}catch(Exception e)
			{
				e.printStackTrace();
			}
			int k=0;
			res.previous();
			pw.println("<table align='center'><tr><th>"+src+" to "+dest+"</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>"+date+"</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>"+operator+"</th><tr></table>");
			pw.println("<br>");pw.println("<br>");
			pw.println("<table align='center'><tr><th>passenger name</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>age</th></tr>");
			while(res.next())
			{
				k=fare1+k;
				pw.println("<tr><td>"+res.getString("name")+"</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>"+res.getString("age")+"age</td></tr>");
			}
			pw.println("</table><br>");pw.println("<br>");
			pw.println("<table align='center'><tr><th>Total Fare</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>Boarding Address</th><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><th>Departure Time</th></tr><tr><td>"+k+"</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>"+stadd+"</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>"+dtime+"</td><td></td></tr></table>");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	}

}
