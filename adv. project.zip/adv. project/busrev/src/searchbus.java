

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class searchbus extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		PrintWriter pw=response.getWriter();
	
		pw.println("<html><head><title>Bootstrap Example</title><script src='../jquery.min.js'></script><script src='../bootstrap.min.js'></script>");
		pw.println("<link rel='stylesheet' href='../bootstrap.min.css'><link rel='stylesheet' type='text/css' href='../manager1.css'>");
		pw.println("<link rel='stylesheet' type='text/css' href='../manager.css'><link rel='stylesheet' type='text/css' href='../navigationbar.css'></head>");
		pw.println("<body><div id='main'><div id='div1'><ul id='ul1'><li id='dreamtravel'><font style='color: #ffffff'>DREAM TRAVEL</font></li><li id='home'><a href='#home'>Home</a></li>");
		pw.println("<li style='float:right' id='log out'><a class='active' href='../login1.html'>Log Out</a></li></ul></div><div id='div2'><div id='div21'><ul><li><a  href='../manager.html'>Add New Bus</a></li>");
		pw.println("<li><a  href='servlet/viewregistereduser'>View Registered User</a></li><li><a class='active' href='../searchbus.html'>Search bus</a></li><li><a href='../delete.html'>Delete Bus</a></li></ul></div>");
		pw.println("<div id='div22'>");
		
		pw.println(" <div class='container'> <div class='row'> <div class='panel panel-default'>");
		pw.println("<div class='panel-heading'></div><table class='table table-fixed'>");
		pw.println("<thead> <tr><th class='col-xs-2'>Operator</th><th class='col-xs-8'>BusType</th><th class='col-xs-2'>Departure</th><th class='col-xs-2'>Arrival</th><th class='col-xs-2'>Number of Seat</th><th class='col-xs-2'>Price</th></tr></thead>");
		String s1=request.getParameter("src");
		String s2=request.getParameter("dest");
		String s3=request.getParameter("date");
		Connection con=DbInfo1.con;
		String str="select operator,type,dtime,atime,numseat,fare from bus where srcstn=? AND deststn=?";
		try {
			PreparedStatement ps=con.prepareStatement(str);
			ps.setString(1, s1);
			ps.setString(2, s2);
			System.out.println(s1);
			System.out.println(s2);
			ResultSet rs=ps.executeQuery();
			pw.println("<div class='scrollit'><tbody>");
			while(rs.next())
			{
				String operator=rs.getString("operator");
				String bustype=rs.getString("type");
				String dtime=rs.getString("dtime");
				String atime=rs.getString("atime");
				String numseat=rs.getString("numseat");
				String fare=rs.getString("fare");
				  
				pw.println("<tr><td class='col-xs-2'>"+operator+"</td><td class='col-xs-8'>"+bustype+"</td><td class='col-xs-2'>"+dtime+"</td><td class='col-xs-2'>"+atime+"</td><td class='col-xs-2'>"+numseat+"</td><td class='col-xs-2'>"+fare+"</td>");
				pw.println("</td></tr>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		            
		pw.println("</div></tbody></table>");
		pw.println("</div></div></div></div>");
		pw.println("<div id='div6'><table id='table61'><tr><td>");
		pw.println("<a href='https://www.goibibo.com/'><img src='../Goibibo.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td>");
		pw.println("<a href='https://www.tripadvisor.in/'><img src='../tripavisor.png' alt='HTML tutorial' style='width:100px;height:100px;border:0;'></a><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td><td>&nbsp;</td></td><td ><img src='../rat.jpg' ></td></tr></table></div></div></body></html>");

	}        
	    
	}

