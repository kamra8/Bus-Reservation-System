

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class login
 */
@WebServlet("/login")
public class login1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		    String name=request.getParameter("uname");
	        String pass=request.getParameter("pass");
	        String utype="";
	        int flag=0;
	        Connection con=DbInfo1.con;
	        String query="select * from reg where username=? and password=?";
	        try
	        {
	        	PreparedStatement ps=con.prepareStatement(query);
	        	ps.setString(1, name);
	        	ps.setString(2, pass);
	        	ResultSet res=ps.executeQuery();
	        	while(res.next())
	        	{
	        		flag=1;
	        		utype=res.getString(3);
	        	}
	        }
	        catch(Exception e)
	        {
	        	e.printStackTrace();
	        }
	        if(flag==1)
	        {
	             
	             if(utype.equalsIgnoreCase("manager"))
	             {
	            	 response.sendRedirect("../manager.html");
	             }
	             else
	             {
	            	 response.sendRedirect("../customersearchbus.html");
	             }
	        }
	        else
	        {
	        	response.sendRedirect("../login1.html");
	        }
	        
	    }
	}

