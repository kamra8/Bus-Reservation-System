

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class manageraddbus
 */
@WebServlet("/manageraddbus")
public class manageraddbus extends HttpServlet {
	int i=0;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public manageraddbus() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
		Connection con=DbInfo1.con;
		String query="insert into bus values(?,?,?,?,?,?,?,?,?,?,?,?)";
		try {
			PreparedStatement ps=con.prepareStatement(query);
			String s1=request.getParameter("idd");
			String s2=request.getParameter("no");
			String s3=request.getParameter("type");
			String s4=request.getParameter("operator");
			String s5=request.getParameter("srcstn");
			String s6=request.getParameter("deststn");
			String s7=request.getParameter("fare");
			String s8=request.getParameter("dtime");
			String s9=request.getParameter("atime");
			String s10=request.getParameter("stadd");
			String s11=request.getParameter("contact");
			String s12=request.getParameter("numseat");
			ps.setString(1, s1);
			ps.setString(2, s2);
			ps.setString(3, s3);
			ps.setString(4, s4);
			ps.setString(5, s5);
			ps.setString(6, s6);
			ps.setString(7, s7);
			ps.setString(8, s8);
			ps.setString(9, s9);
			ps.setString(10, s10);
			ps.setString(11, s11);
			ps.setString(12, s12);
			i=ps.executeUpdate();
			
		}
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		response.sendRedirect("../manager.html");
	}

}
